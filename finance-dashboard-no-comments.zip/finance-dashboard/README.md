# Ledger — Personal Finance Dashboard

A full-stack dashboard for exploring the `Personal_Finance_Dataset.csv` transaction
history (1,500 transactions, 2020–2024, 10 categories, Income/Expense).

- **Backend:** Python + Flask REST API. Loads the CSV into a pandas DataFrame
  on startup and exposes summary, category-breakdown, monthly-trend, and
  paginated transaction endpoints — plus three scikit-learn-powered ML
  endpoints (forecasting, anomaly detection, category clustering).
- **Frontend:** React + Vite, charts via Recharts. A dark "ledger" aesthetic —
  monospaced figures, a torn-tape summary header, dotted-leader category rows —
  built to look like a real statement rather than a generic admin template.

## Project structure

```
finance-dashboard/
├── backend/
│   ├── data/
│   │   ├── Personal_Finance_Dataset.csv
│   │   └── loader.py           # CSV -> normalized pandas DataFrame
│   ├── routes/
│   │   └── api.py              # all REST + ML endpoints
│   ├── ml/
│   │   └── models.py           # LinearRegression, IsolationForest, KMeans
│   ├── app.py                  # Flask app entry point
│   └── requirements.txt
└── frontend/
    ├── src/
    │   ├── components/
    │   │   ├── Filters.jsx
    │   │   ├── SummaryCards.jsx
    │   │   ├── TrendChart.jsx
    │   │   ├── CategoryBreakdown.jsx
    │   │   └── TransactionsTable.jsx
    │   ├── api.js              # axios client
    │   ├── categoryColors.js
    │   ├── App.jsx
    │   ├── main.jsx
    │   └── index.css
    ├── index.html
    ├── vite.config.js
    └── package.json
```

## Running it

You need two terminals (or run one, then the other in the background).

### 1. Backend (port 4000)

Requires Python 3.10+.

```bash
cd backend
python3 -m venv venv && source venv/bin/activate   # optional but recommended
pip install -r requirements.txt
python3 app.py
```

Visit `http://localhost:4000/` to see the list of available endpoints, or
`http://localhost:4000/api/summary` directly.

### 2. Frontend (port 5173)

```bash
cd frontend
npm install
npm run dev
```

Visit `http://localhost:5173`. The Vite dev server proxies any `/api/*`
request to `http://localhost:4000` (see `vite.config.js`), so no CORS
configuration is needed in development.

### Production build

```bash
cd frontend
npm run build   # outputs static files to frontend/dist
npm run preview # serve the built files locally to sanity-check
```

Deploy `frontend/dist` behind any static host, and point it at wherever you
deploy the `backend` (update the `axios` baseURL in `src/api.js` or add a
reverse proxy in front of both).

## API reference

| Method | Path                     | Purpose                                                        |
|--------|--------------------------|------------------------------------------------------------------|
| GET    | `/api/meta`              | Dataset date range and total transaction count                 |
| GET    | `/api/categories`        | Distinct category list (for filter dropdowns)                  |
| GET    | `/api/summary`           | Totals, net, savings rate, averages, biggest income/expense     |
| GET    | `/api/breakdown/category`| Income/expense/net totals grouped by category                  |
| GET    | `/api/trends/monthly`    | Income/expense/net totals grouped by month                     |
| GET    | `/api/transactions`      | Paginated, sortable, filterable transaction list                |
| GET    | `/api/ml/forecast`       | **Linear Regression** — projects income/expense/net `periods` months ahead (default 3) |
| GET    | `/api/ml/anomalies`      | **Isolation Forest** — flags unusual transactions per category, with an `anomalyScore` |
| GET    | `/api/ml/clusters`       | **KMeans** — groups categories into spending-behavior tiers (`clusters`, default 3) |

All endpoints accept the same optional query filters:

- `category` — exact category name, or omit/`All` for everything
- `type` — `Income`, `Expense`, or omit/`All`
- `startDate`, `endDate` — `YYYY-MM-DD`, inclusive
- `search` — case-insensitive match against transaction description

`/api/transactions` additionally accepts `page`, `pageSize` (default 25, max
200), `sort` (any transaction field), and `order` (`asc`/`desc`).

## ML endpoints (`backend/ml/models.py`)

Three scikit-learn models, each tackling a distinct problem:

1. **Forecasting — Linear Regression.** Fits a trend line over monthly
   income and expense totals and projects it forward. Returns the full
   history plus `periods` future months flagged `"predicted": true`.
2. **Anomaly detection — Isolation Forest.** Scores every transaction
   against its category's typical amount/day-of-month pattern and returns
   the top outliers with an `anomalyScore` (higher = more unusual).
3. **Category clustering — KMeans.** Groups categories by total spend,
   average transaction size, and frequency into behavior tiers ("High
   spend", "Moderate spend", "Low spend", ...).

All three accept the same filters as the other endpoints (`category`,
`type`, `startDate`, `endDate`, `search`), plus their own tuning params
(`periods` for forecast, `clusters` for clustering).

## Notes on the dataset

The CSV columns are `Date, Transaction Description, Category, Amount, Type`.
Categories present: Food & Drink, Utilities, Rent, Investment, Shopping,
Other, Entertainment, Health & Fitness, Salary, Travel. `Type` is either
`Income` or `Expense`. The backend loads and normalizes this into a pandas
DataFrame once at startup — there's no database, so restarting the server
re-reads the CSV. Swap `data/loader.py` for a real database call if you
outgrow the in-memory approach.
