import os

from flask import Flask, jsonify

from data.loader import load_transactions
from routes.api import build_api_blueprint

PORT = int(os.environ.get("PORT", 4000))

app = Flask(__name__)

@app.after_request
def add_cors_headers(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type, Authorization"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, DELETE, OPTIONS"
    return response

transactions = load_transactions()
print(f"Loaded {len(transactions)} transactions.")

app.register_blueprint(build_api_blueprint(transactions), url_prefix="/api")

@app.get("/")
def root():
    return jsonify({
        "name": "Personal Finance Dashboard API",
        "endpoints": [
            "GET /api/meta",
            "GET /api/categories",
            "GET /api/summary",
            "GET /api/breakdown/category",
            "GET /api/trends/monthly",
            "GET /api/transactions",
            "GET /api/ml/forecast",
            "GET /api/ml/anomalies",
            "GET /api/ml/clusters",
        ],
    })

if __name__ == "__main__":
    print(f"Finance dashboard API running at http://localhost:{PORT}")
    app.run(host="0.0.0.0", port=PORT, debug=False)
