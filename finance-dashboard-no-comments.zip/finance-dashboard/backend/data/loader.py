import os
import pandas as pd

CSV_PATH = os.path.join(os.path.dirname(__file__), "Personal_Finance_Dataset.csv")

def load_transactions() -> pd.DataFrame:
    df = pd.read_csv(CSV_PATH, dtype=str)

    df = df.dropna(subset=["Date", "Category", "Amount"])
    df = df[(df["Date"].str.strip() != "") & (df["Category"].str.strip() != "")]

    df["amount"] = pd.to_numeric(df["Amount"], errors="coerce").fillna(0).round(2)
    df["date"] = df["Date"].str.strip()
    df["month"] = df["date"].str.slice(0, 7)
    df["year"] = df["date"].str.slice(0, 4)
    df["description"] = df.get("Transaction Description", "").fillna("").str.strip()
    df["category"] = df["Category"].str.strip()
    df["type"] = df["Type"].fillna("").str.strip().apply(
        lambda t: "Income" if t == "Income" else "Expense"
    )

    df = df.sort_values("date", kind="stable").reset_index(drop=True)
    df["id"] = df.index + 1

    return df[["id", "date", "month", "year", "description", "category", "amount", "type"]]
