import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import IsolationForest
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

def _round2(x):
    return round(float(x), 2)

def forecast_monthly(df: pd.DataFrame, periods: int = 3) -> list[dict]:
    if df.empty:
        return []

    monthly = (
        df.groupby("month")
        .apply(
            lambda g: pd.Series(
                {
                    "income": g.loc[g["type"] == "Income", "amount"].sum(),
                    "expense": g.loc[g["type"] == "Expense", "amount"].sum(),
                }
            ),
            include_groups=False,
        )
        .reset_index()
        .sort_values("month")
        .reset_index(drop=True)
    )

    history = [
        {
            "month": row["month"],
            "income": _round2(row["income"]),
            "expense": _round2(row["expense"]),
            "net": _round2(row["income"] - row["expense"]),
            "predicted": False,
        }
        for _, row in monthly.iterrows()
    ]

    if len(monthly) < 2:
        return history

    x = np.arange(len(monthly)).reshape(-1, 1)

    income_model = LinearRegression().fit(x, monthly["income"].values)
    expense_model = LinearRegression().fit(x, monthly["expense"].values)

    last_month = pd.Period(monthly["month"].iloc[-1], freq="M")
    future = []
    for step in range(1, periods + 1):
        future_x = np.array([[len(monthly) + step - 1]])
        pred_income = max(0.0, float(income_model.predict(future_x)[0]))
        pred_expense = max(0.0, float(expense_model.predict(future_x)[0]))
        future_month = (last_month + step).strftime("%Y-%m")
        future.append(
            {
                "month": future_month,
                "income": _round2(pred_income),
                "expense": _round2(pred_expense),
                "net": _round2(pred_income - pred_expense),
                "predicted": True,
            }
        )

    return history + future

def detect_anomalies(df: pd.DataFrame, contamination: float = 0.03) -> list[dict]:
    if len(df) < 20:
        return []

    work = df.copy()
    work["day"] = pd.to_datetime(work["date"], errors="coerce").dt.day.fillna(1)

    cat_dummies = pd.get_dummies(work["category"], prefix="cat")
    type_dummies = pd.get_dummies(work["type"], prefix="type")

    features = pd.concat(
        [work[["amount", "day"]], cat_dummies, type_dummies], axis=1
    )
    scaled = StandardScaler().fit_transform(features)

    model = IsolationForest(
        n_estimators=200,
        contamination=contamination,
        random_state=42,
    )
    work["anomaly_flag"] = model.fit_predict(scaled)
    work["anomaly_score"] = -model.decision_function(scaled)

    anomalies = (
        work[work["anomaly_flag"] == -1]
        .sort_values("anomaly_score", ascending=False)
        .head(50)
    )

    return [
        {
            "id": int(row["id"]),
            "date": row["date"],
            "description": row["description"],
            "category": row["category"],
            "amount": _round2(row["amount"]),
            "type": row["type"],
            "anomalyScore": _round2(row["anomaly_score"]),
        }
        for _, row in anomalies.iterrows()
    ]

def cluster_categories(df: pd.DataFrame, n_clusters: int = 3) -> list[dict]:
    expense = df[df["type"] == "Expense"]
    if expense.empty:
        return []

    grouped = (
        expense.groupby("category")["amount"]
        .agg(total="sum", average="mean", count="count")
        .reset_index()
    )

    k = min(n_clusters, len(grouped))
    if k < 2:
        grouped["cluster"] = 0
        grouped["clusterLabel"] = "All spending"
    else:
        features = grouped[["total", "average", "count"]]
        scaled = StandardScaler().fit_transform(features)

        model = KMeans(n_clusters=k, n_init=10, random_state=42)
        grouped["cluster"] = model.fit_predict(scaled)

        rank = (
            grouped.groupby("cluster")["total"]
            .mean()
            .sort_values(ascending=False)
            .index.tolist()
        )
        tiers = ["High spend", "Moderate spend", "Low spend", "Minimal spend"]
        label_map = {
            cluster_id: tiers[i] if i < len(tiers) else f"Tier {i + 1}"
            for i, cluster_id in enumerate(rank)
        }
        grouped["clusterLabel"] = grouped["cluster"].map(label_map)

    return [
        {
            "category": row["category"],
            "totalSpend": _round2(row["total"]),
            "avgTransaction": _round2(row["average"]),
            "transactionCount": int(row["count"]),
            "cluster": int(row["cluster"]),
            "clusterLabel": row["clusterLabel"],
        }
        for _, row in grouped.sort_values("total", ascending=False).iterrows()
    ]
