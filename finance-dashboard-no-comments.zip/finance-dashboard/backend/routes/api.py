import math
import pandas as pd
from flask import Blueprint, jsonify, request

from ml import models as ml

def _round2(n):
    return round(float(n), 2)

def apply_filters(df: pd.DataFrame, args) -> pd.DataFrame:
    result = df

    category = args.get("category")
    type_ = args.get("type")
    start_date = args.get("startDate")
    end_date = args.get("endDate")
    search = args.get("search")

    if category and category != "All":
        result = result[result["category"] == category]
    if type_ and type_ != "All":
        result = result[result["type"] == type_]
    if start_date:
        result = result[result["date"] >= start_date]
    if end_date:
        result = result[result["date"] <= end_date]
    if search:
        q = search.lower()
        result = result[result["description"].str.lower().str.contains(q, na=False)]

    return result

def build_api_blueprint(transactions: pd.DataFrame) -> Blueprint:
    bp = Blueprint("api", __name__)

    @bp.get("/transactions")
    def get_transactions():
        filtered = apply_filters(transactions, request.args)

        sort_key = request.args.get("sort", "date")
        order = request.args.get("order", "desc")
        ascending = order == "asc"
        if sort_key in filtered.columns:
            filtered = filtered.sort_values(sort_key, ascending=ascending, kind="stable")

        page = max(int(request.args.get("page", 1) or 1), 1)
        page_size = min(max(int(request.args.get("pageSize", 25) or 25), 1), 200)
        start = (page - 1) * page_size

        total = len(filtered)
        page_rows = filtered.iloc[start:start + page_size]

        return jsonify({
            "total": total,
            "page": page,
            "pageSize": page_size,
            "totalPages": max(math.ceil(total / page_size), 1),
            "rows": page_rows.to_dict(orient="records"),
        })

    @bp.get("/categories")
    def get_categories():
        cats = sorted(transactions["category"].unique().tolist())
        return jsonify({"categories": ["All"] + cats})

    @bp.get("/summary")
    def get_summary():
        filtered = apply_filters(transactions, request.args)

        income = filtered[filtered["type"] == "Income"]
        expense = filtered[filtered["type"] == "Expense"]

        total_income = _round2(income["amount"].sum())
        total_expense = _round2(expense["amount"].sum())
        net = _round2(total_income - total_expense)

        savings_rate = _round2((net / total_income) * 100) if total_income > 0 else 0

        avg_expense = _round2(expense["amount"].mean()) if len(expense) else 0
        avg_income = _round2(income["amount"].mean()) if len(income) else 0

        biggest_expense = (
            expense.loc[expense["amount"].idxmax()].to_dict() if len(expense) else None
        )
        biggest_income = (
            income.loc[income["amount"].idxmax()].to_dict() if len(income) else None
        )

        return jsonify({
            "totalIncome": total_income,
            "totalExpense": total_expense,
            "net": net,
            "savingsRate": savings_rate,
            "transactionCount": int(len(filtered)),
            "avgExpense": avg_expense,
            "avgIncome": avg_income,
            "biggestExpense": biggest_expense,
            "biggestIncome": biggest_income,
        })

    @bp.get("/breakdown/category")
    def get_category_breakdown():
        filtered = apply_filters(transactions, request.args)

        rows = []
        for category, group in filtered.groupby("category"):
            income = _round2(group.loc[group["type"] == "Income", "amount"].sum())
            expense = _round2(group.loc[group["type"] == "Expense", "amount"].sum())
            rows.append({
                "category": category,
                "income": income,
                "expense": expense,
                "count": int(len(group)),
                "net": _round2(income - expense),
            })

        rows.sort(key=lambda r: r["expense"] + r["income"], reverse=True)
        return jsonify({"rows": rows})

    @bp.get("/trends/monthly")
    def get_monthly_trends():
        filtered = apply_filters(transactions, request.args)

        rows = []
        for month, group in filtered.groupby("month"):
            income = _round2(group.loc[group["type"] == "Income", "amount"].sum())
            expense = _round2(group.loc[group["type"] == "Expense", "amount"].sum())
            rows.append({
                "month": month,
                "income": income,
                "expense": expense,
                "net": _round2(income - expense),
            })

        rows.sort(key=lambda r: r["month"])
        return jsonify({"rows": rows})

    @bp.get("/meta")
    def get_meta():
        return jsonify({
            "minDate": transactions["date"].min(),
            "maxDate": transactions["date"].max(),
            "transactionCount": int(len(transactions)),
        })

    @bp.get("/ml/forecast")
    def get_forecast():
        filtered = apply_filters(transactions, request.args)
        periods = min(max(int(request.args.get("periods", 3) or 3), 1), 12)
        return jsonify({"rows": ml.forecast_monthly(filtered, periods=periods)})

    @bp.get("/ml/anomalies")
    def get_anomalies():
        filtered = apply_filters(transactions, request.args)
        return jsonify({"rows": ml.detect_anomalies(filtered)})

    @bp.get("/ml/clusters")
    def get_clusters():
        filtered = apply_filters(transactions, request.args)
        n_clusters = min(max(int(request.args.get("clusters", 3) or 3), 2), 6)
        return jsonify({"rows": ml.cluster_categories(filtered, n_clusters=n_clusters)})

    return bp
