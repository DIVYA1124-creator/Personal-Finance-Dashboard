import { useEffect, useState, useCallback } from "react";
import { api } from "./api";
import Filters from "./components/Filters";
import SummaryCards from "./components/SummaryCards";
import TrendChart from "./components/TrendChart";
import CategoryBreakdown from "./components/CategoryBreakdown";
import TransactionsTable from "./components/TransactionsTable";

const DEFAULT_FILTERS = {
  category: "All",
  type: "All",
  startDate: "",
  endDate: "",
  search: "",
};

export default function App() {
  const [meta, setMeta] = useState(null);
  const [categories, setCategories] = useState(["All"]);
  const [filters, setFilters] = useState(DEFAULT_FILTERS);

  const [summary, setSummary] = useState(null);
  const [trendRows, setTrendRows] = useState([]);
  const [breakdownRows, setBreakdownRows] = useState([]);
  const [breakdownType, setBreakdownType] = useState("Expense");

  const [tx, setTx] = useState({ rows: [], total: 0, totalPages: 1 });
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState("date");
  const [order, setOrder] = useState("desc");
  const [loadingTx, setLoadingTx] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    api
      .getMeta()
      .then((m) => {
        setMeta(m);
        setFilters((f) => ({ ...f, startDate: m.minDate, endDate: m.maxDate }));
      })
      .catch(() => setError("Could not reach the API. Is the backend running on port 4000?"));

    api.getCategories().then((c) => setCategories(c.categories)).catch(() => {});
  }, []);

  useEffect(() => {
    if (!filters.startDate) return;
    api.getSummary(filters).then(setSummary).catch(() => {});
    api.getMonthlyTrends(filters).then((r) => setTrendRows(r.rows)).catch(() => {});
    api
      .getCategoryBreakdown(filters)
      .then((r) => setBreakdownRows(r.rows))
      .catch(() => {});
  }, [filters]);

  const loadTransactions = useCallback(() => {
    if (!filters.startDate) return;
    setLoadingTx(true);
    api
      .getTransactions({ ...filters, page, pageSize: 10, sort, order })
      .then((r) => setTx(r))
      .catch(() => setError("Could not load transactions."))
      .finally(() => setLoadingTx(false));
  }, [filters, page, sort, order]);

  useEffect(() => {
    loadTransactions();
  }, [loadTransactions]);

  useEffect(() => {
    setPage(1);
  }, [filters]);

  function handleFiltersChange(next) {
    setFilters(next);
  }

  function handleReset() {
    setFilters({ ...DEFAULT_FILTERS, startDate: meta?.minDate ?? "", endDate: meta?.maxDate ?? "" });
  }

  function handleSortChange(key, ord) {
    setSort(key);
    setOrder(ord);
  }

  const rangeLabel =
    filters.startDate && filters.endDate ? `${filters.startDate} → ${filters.endDate}` : "—";

  return (
    <div className="app-shell">
      <header className="app-header">
        <h1 className="app-title">
          <span className="ledger-mark">§</span> Ledger
        </h1>
        <span className="app-subtitle">
          {meta ? `${meta.transactionCount.toLocaleString()} entries on file` : "loading…"}
        </span>
      </header>

      {error && <div className="panel state-msg">{error}</div>}

      <SummaryCards summary={summary} rangeLabel={rangeLabel} />

      <div className="panel">
        <div className="panel-head">
          <h2 className="panel-title">Filter the ledger</h2>
          <span className="panel-note">applies to every section below</span>
        </div>
        <Filters
          filters={filters}
          onChange={handleFiltersChange}
          onReset={handleReset}
          categories={categories}
          meta={meta}
        />
      </div>

      <div className="grid-2">
        <div className="panel">
          <div className="panel-head">
            <h2 className="panel-title">Income vs. expense over time</h2>
            <span className="panel-note">monthly totals, net shown as dashed line</span>
          </div>
          <TrendChart rows={trendRows} />
        </div>

        <div className="panel">
          <div className="panel-head">
            <h2 className="panel-title">By category</h2>
            <div style={{ display: "flex", gap: 6 }}>
              <button
                className="filter-reset"
                style={{
                  borderColor: breakdownType === "Expense" ? "var(--accent-gold)" : undefined,
                  color: breakdownType === "Expense" ? "var(--accent-gold)" : undefined,
                }}
                onClick={() => setBreakdownType("Expense")}
                type="button"
              >
                Expense
              </button>
              <button
                className="filter-reset"
                style={{
                  borderColor: breakdownType === "Income" ? "var(--accent-gold)" : undefined,
                  color: breakdownType === "Income" ? "var(--accent-gold)" : undefined,
                }}
                onClick={() => setBreakdownType("Income")}
                type="button"
              >
                Income
              </button>
            </div>
          </div>
          <CategoryBreakdown rows={breakdownRows} type={breakdownType} />
        </div>
      </div>

      <div className="panel">
        <div className="panel-head">
          <h2 className="panel-title">Transaction register</h2>
          <span className="panel-note">
            {tx.total.toLocaleString()} matching entries · click a column to sort
          </span>
        </div>
        <TransactionsTable
          data={tx.rows}
          sort={sort}
          order={order}
          onSortChange={handleSortChange}
          page={tx.page || page}
          totalPages={tx.totalPages || 1}
          onPageChange={setPage}
          loading={loadingTx}
        />
      </div>

      <footer className="app-footer">
        Personal Finance Dashboard — Express API + React/Vite frontend, reading from
        Personal_Finance_Dataset.csv
      </footer>
    </div>
  );
}
