import axios from "axios";

const client = axios.create({ baseURL: "/api" });

function cleanParams(params = {}) {
  const out = {};
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== "" && v !== "All") out[k] = v;
  });
  return out;
}

export const api = {
  getMeta: () => client.get("/meta").then((r) => r.data),
  getCategories: () => client.get("/categories").then((r) => r.data),
  getSummary: (filters) =>
    client.get("/summary", { params: cleanParams(filters) }).then((r) => r.data),
  getCategoryBreakdown: (filters) =>
    client.get("/breakdown/category", { params: cleanParams(filters) }).then((r) => r.data),
  getMonthlyTrends: (filters) =>
    client.get("/trends/monthly", { params: cleanParams(filters) }).then((r) => r.data),
  getTransactions: (filters) =>
    client.get("/transactions", { params: cleanParams(filters) }).then((r) => r.data),
};
