const PALETTE = [
  "#3fbf95",
  "#e2725b",
  "#d9a94e",
  "#6f9ceb",
  "#c77dff",
  "#e0a458",
  "#4fb6c7",
  "#e06c93",
  "#8bd17c",
  "#b39ddb",
];

const cache = new Map();

export function colorForCategory(category) {
  if (cache.has(category)) return cache.get(category);
  const color = PALETTE[cache.size % PALETTE.length];
  cache.set(category, color);
  return color;
}
