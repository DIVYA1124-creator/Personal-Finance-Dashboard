import { colorForCategory } from "../categoryColors";

function fmtCurrency(n) {
  const sign = n < 0 ? "-" : "";
  return `${sign}$${Math.abs(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export default function CategoryBreakdown({ rows, type }) {
  if (!rows || rows.length === 0) {
    return <div className="state-msg">No data for the selected filters.</div>;
  }

  const key = type === "Income" ? "income" : "expense";
  const sorted = [...rows].filter((r) => r[key] > 0).sort((a, b) => b[key] - a[key]);

  if (sorted.length === 0) {
    return <div className="state-msg">No {type.toLowerCase()} entries in range.</div>;
  }

  return (
    <div>
      {sorted.map((r) => (
        <div className="ledger-row" key={r.category}>
          <span
            className="row-swatch"
            style={{ background: colorForCategory(r.category) }}
          />
          <span className="row-label">{r.category}</span>
          <span className="row-leader" />
          <span className={`row-value ${key}`}>{fmtCurrency(r[key])}</span>
        </div>
      ))}
    </div>
  );
}
