export default function Filters({ filters, onChange, onReset, categories, meta }) {
  function set(key, value) {
    onChange({ ...filters, [key]: value });
  }

  return (
    <div className="filters-bar">
      <div className="filter-field">
        <label htmlFor="f-category">Category</label>
        <select
          id="f-category"
          value={filters.category}
          onChange={(e) => set("category", e.target.value)}
        >
          {categories.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
      </div>

      <div className="filter-field">
        <label htmlFor="f-type">Type</label>
        <select id="f-type" value={filters.type} onChange={(e) => set("type", e.target.value)}>
          <option value="All">All</option>
          <option value="Income">Income</option>
          <option value="Expense">Expense</option>
        </select>
      </div>

      <div className="filter-field">
        <label htmlFor="f-start">From</label>
        <input
          id="f-start"
          type="date"
          min={meta?.minDate}
          max={meta?.maxDate}
          value={filters.startDate}
          onChange={(e) => set("startDate", e.target.value)}
        />
      </div>

      <div className="filter-field">
        <label htmlFor="f-end">To</label>
        <input
          id="f-end"
          type="date"
          min={meta?.minDate}
          max={meta?.maxDate}
          value={filters.endDate}
          onChange={(e) => set("endDate", e.target.value)}
        />
      </div>

      <div className="filter-field" style={{ flex: 1, minWidth: 180 }}>
        <label htmlFor="f-search">Search description</label>
        <input
          id="f-search"
          type="text"
          placeholder="e.g. grocery, rent…"
          value={filters.search}
          onChange={(e) => set("search", e.target.value)}
        />
      </div>

      <button className="filter-reset" onClick={onReset} type="button">
        Reset filters
      </button>
    </div>
  );
}
