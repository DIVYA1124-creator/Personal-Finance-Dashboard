function fmtCurrency(n) {
  const sign = n < 0 ? "-" : "";
  return `${sign}$${Math.abs(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export default function SummaryCards({ summary, rangeLabel }) {
  if (!summary) return null;

  const isPositive = summary.net >= 0;

  return (
    <div className="ledger-tape">
      <div className="tape-row">
        <span>Statement period</span>
        <span className="tape-ticks" />
        <span>{rangeLabel}</span>
      </div>

      <div className="tape-net">
        <span className="net-label">Net position</span>
        <span className={`net-figure ${isPositive ? "positive" : "negative"}`}>
          {fmtCurrency(summary.net)}
        </span>
        <span className="app-subtitle" style={{ marginLeft: 4 }}>
          savings rate {summary.savingsRate}%
        </span>
      </div>

      <div className="stamp-grid">
        <div className="stamp">
          <div className="stamp-label">Income</div>
          <div className="stamp-value income">{fmtCurrency(summary.totalIncome)}</div>
          <div className="stamp-sub">avg {fmtCurrency(summary.avgIncome)} / entry</div>
        </div>
        <div className="stamp">
          <div className="stamp-label">Expense</div>
          <div className="stamp-value expense">{fmtCurrency(summary.totalExpense)}</div>
          <div className="stamp-sub">avg {fmtCurrency(summary.avgExpense)} / entry</div>
        </div>
        <div className="stamp">
          <div className="stamp-label">Transactions</div>
          <div className="stamp-value">{summary.transactionCount.toLocaleString()}</div>
          <div className="stamp-sub">matching current filters</div>
        </div>
        <div className="stamp">
          <div className="stamp-label">Largest expense</div>
          <div className="stamp-value expense">
            {summary.biggestExpense ? fmtCurrency(summary.biggestExpense.amount) : "—"}
          </div>
          <div className="stamp-sub">
            {summary.biggestExpense ? summary.biggestExpense.category : "no data"}
          </div>
        </div>
      </div>
    </div>
  );
}
