import { colorForCategory } from "../categoryColors";

function fmtCurrency(n) {
  return `$${Number(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

const COLUMNS = [
  { key: "date", label: "Date" },
  { key: "description", label: "Description" },
  { key: "category", label: "Category" },
  { key: "type", label: "Type" },
  { key: "amount", label: "Amount" },
];

export default function TransactionsTable({
  data,
  sort,
  order,
  onSortChange,
  page,
  totalPages,
  onPageChange,
  loading,
}) {
  function handleHeaderClick(key) {
    if (sort === key) {
      onSortChange(key, order === "asc" ? "desc" : "asc");
    } else {
      onSortChange(key, "desc");
    }
  }

  return (
    <div>
      <div className="table-wrap">
        <table className="tx-table">
          <thead>
            <tr>
              {COLUMNS.map((col) => (
                <th key={col.key} onClick={() => handleHeaderClick(col.key)}>
                  {col.label} {sort === col.key ? (order === "asc" ? "▲" : "▼") : ""}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {loading && (
              <tr>
                <td colSpan={5} className="state-msg">
                  Loading…
                </td>
              </tr>
            )}
            {!loading && data.length === 0 && (
              <tr>
                <td colSpan={5} className="state-msg">
                  No transactions match these filters.
                </td>
              </tr>
            )}
            {!loading &&
              data.map((t) => (
                <tr key={t.id}>
                  <td>{t.date}</td>
                  <td className="desc-cell">{t.description}</td>
                  <td>
                    <span
                      className="cat-chip"
                      style={{ borderColor: colorForCategory(t.category) }}
                    >
                      {t.category}
                    </span>
                  </td>
                  <td>{t.type}</td>
                  <td className={`amount-cell ${t.type === "Income" ? "income" : "expense"}`}>
                    {t.type === "Income" ? "+" : "−"}
                    {fmtCurrency(t.amount)}
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>

      <div className="pagination">
        <span>
          Page {page} of {totalPages}
        </span>
        <button disabled={page <= 1} onClick={() => onPageChange(page - 1)} type="button">
          ← Prev
        </button>
        <button
          disabled={page >= totalPages}
          onClick={() => onPageChange(page + 1)}
          type="button"
        >
          Next →
        </button>
      </div>
    </div>
  );
}
