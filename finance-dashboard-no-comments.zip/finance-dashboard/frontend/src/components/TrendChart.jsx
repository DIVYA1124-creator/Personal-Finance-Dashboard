import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";

function fmtMonth(m) {
  const [y, mo] = m.split("-");
  const d = new Date(Number(y), Number(mo) - 1);
  return d.toLocaleDateString("en-US", { month: "short", year: "2-digit" });
}

function fmtCurrency(n) {
  return `$${Number(n).toLocaleString("en-US", { maximumFractionDigits: 0 })}`;
}

export default function TrendChart({ rows }) {
  if (!rows || rows.length === 0) {
    return <div className="state-msg">No data for the selected filters.</div>;
  }

  const data = rows.map((r) => ({ ...r, monthLabel: fmtMonth(r.month) }));

  return (
    <ResponsiveContainer width="100%" height={280}>
      <ComposedChart data={data} margin={{ top: 6, right: 12, left: -12, bottom: 0 }}>
        <CartesianGrid stroke="#232c38" vertical={false} />
        <XAxis
          dataKey="monthLabel"
          tick={{ fill: "#8d97a3", fontSize: 11, fontFamily: "IBM Plex Mono" }}
          axisLine={{ stroke: "#2b3542" }}
          tickLine={false}
          interval="preserveStartEnd"
        />
        <YAxis
          tick={{ fill: "#8d97a3", fontSize: 11, fontFamily: "IBM Plex Mono" }}
          axisLine={false}
          tickLine={false}
          tickFormatter={fmtCurrency}
          width={64}
        />
        <Tooltip
          formatter={(value, name) => [fmtCurrency(value), name]}
          labelStyle={{ color: "#edeae1" }}
          contentStyle={{ background: "#202a37", border: "1px solid #2b3542" }}
        />
        <Legend
          wrapperStyle={{ fontSize: 12, fontFamily: "IBM Plex Mono", color: "#8d97a3" }}
        />
        <Area
          type="monotone"
          dataKey="income"
          name="Income"
          stroke="#3fbf95"
          fill="#3fbf95"
          fillOpacity={0.12}
          strokeWidth={2}
        />
        <Area
          type="monotone"
          dataKey="expense"
          name="Expense"
          stroke="#e2725b"
          fill="#e2725b"
          fillOpacity={0.12}
          strokeWidth={2}
        />
        <Line
          type="monotone"
          dataKey="net"
          name="Net"
          stroke="#d9a94e"
          strokeWidth={2}
          strokeDasharray="4 3"
          dot={false}
        />
      </ComposedChart>
    </ResponsiveContainer>
  );
}
